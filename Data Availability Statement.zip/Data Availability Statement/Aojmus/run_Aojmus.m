% function results = run_Ours(seq, res_path, bSaveImage)
% 
% 	
% 
% 	%default settings
%     video = 'benchmark';
%     kernel_type = 'gaussian'; 
% 	feature_type = 'hogcolor'; 
% 	
% 	kernel.type = kernel_type;
% 	
% 	features.gray = false;
% 	features.hog = false;
% 	features.hogcolor = false;
% 	padding = 1.5;  %Ŀ����Χ�Ķ�������ٷֱ�
% %     padding = 2;  %extra area surrounding the target
% 
% 	lambda = 1e-4;  %regularization ���ƹ���ϵ����򻯲�����ģ�ͷ����е����Իع�
% 	output_sigma_factor = 0.1;  %spatial bandwidth (proportional to target)�ռ��������Ŀ��ɱ�����
% 	
% 	switch feature_type
% 	case 'gray'
% %		interp_factor = 0.075;  %����Ӧ�����Բ�ֵ����
% 
% 		kernel.sigma = 0.2;  %gaussian kernel bandwidth ��˹�ں˴���
% 		
% 		kernel.poly_a = 1;  %polynomial kernel additive term ����ʽ�˼ӷ���
% 		kernel.poly_b = 7;  %polynomial kernel exponent ����ʽ��ָ��
% 	
% 		features.gray = true;   %�Ҷ�
% 		cell_size = 1;
% 		
% 	case 'hog'
% %		interp_factor = 0.02;  %����Ӧ���Բ�ֵ����
% 		
% 		kernel.sigma = 0.5;   %gaussian kernel bandwidth ��˹�ں˴���
% 		
% 		kernel.poly_a = 1;
% 		kernel.poly_b = 9;
% 		
% 		features.hog = true; %ֱ��ͼ
% 		features.hog_orientations = 9;
% 		cell_size = 4;
%     case 'hogcolor'
% %		interp_factor = 0.01;  %interp_factor�Ǹ�����������Ӧ���ʣ�������ģ�͵ļ�������
% 		
% 		kernel.sigma = 0.5; %��˹�ں˴���		
% 		
% 		kernel.poly_a = 1; %����ʽ�˼ӷ���
% 		kernel.poly_b = 9; %����ʽ�ں�ָ��
% 		
% 		features.hogcolor = true;
% 		features.hog_orientations = 9;
% 		cell_size = 4;
% %     case 'deep'
% % %        interp_factor = 0.02;
% % 		
% % 		kernel.sigma = 0.5;
% % 		
% % 		kernel.poly_a = 1;
% % 		kernel.poly_b = 9;
% % 		
% % 		features.deep = true;  %���
% % 		cell_size = 8;
% %         init_vgg;   %VGG16��ȡͼ������
% 		
% 	otherwise
% 		error('Unknown feature.')
% 	end
% 
% 
% 	
% 		seq = evalin('base_path', 'subS');
% 		target_sz = seq.init_rect(1,[4,3]);%Ŀ���СΪ60x60
% 		pos = seq.init_rect(1,[2,1]) + floor(target_sz/2);
% 		img_files = seq.s_frames;
% 		video_path = [];
% 		
% 		[positions, time] = tracker(video_path, img_files, pos, target_sz, ...
% 			padding, kernel, lambda, output_sigma_factor, ...
% 			cell_size, features, show_visualization);%interp_factor,
% 		
% 		%return results to benchmark, in a workspace variable
% 		rects = [positions(:,2) - target_sz(2)/2, positions(:,1) - target_sz(1)/2];
% 		rects(:,3) = target_sz(2);
% 		rects(:,4) = target_sz(1);
% 
% 		
% 
%     results.res = rects;%each row is a rectangle
% 	results.fps = numel(img_files) / time;
% 	results.type='rect';
% end















function results = run_Aojmus(seq, res_path, bSaveImage)

    kernel.type = 'gaussian'; 

    padding = 1.5;  %extra area surrounding the target
    lambda = 1e-4;  %regularization
    output_sigma_factor = 0.1;  %spatial bandwidth (proportional to target)

   interp_factor = 0.02;
    kernel.sigma = 0.5; 
    kernel.poly_a = 1;
    kernel.poly_b = 9;  
    features.hogcolor = true;
    features.hog_orientations = 9;
    cell_size = 4;  
    show_visualization = 0;
   
     global params;
	%params.output_sigma_factor = 1/16;		% standard deviation for the desired translation filter output
    params.scale_sigma_factor = 1/4;        % standard deviation for the desired scale filter output
    params.lambda = 1e-2;					% regularization weight (denoted "lambda" in the paper)
    params.learning_rate = 0.025;%0.025			% tracking model learning rate (denoted "eta" in the paper)
    params.number_of_scales = 33;           % number of scale levels (denoted "S" in the paper)
    params.scale_step = 1.02;               % Scale increment factor (denoted "a" in the paper)
    params.scale_model_max_area = 512;      % the maximum size of scale examples

    
     seq_Aojmus = seq;
     target_sz = seq_Aojmus.init_rect(1,[4,3]);
     pos = seq_Aojmus.init_rect(1,[2,1]) + floor(target_sz/2);
     img_files = seq_Aojmus.s_frames;
     video_path = [];
     
   
    [positions , time] = tracker(video_path,img_files, pos, target_sz, ...
            padding, kernel, lambda, output_sigma_factor,interp_factor, ...
            cell_size, features,show_visualization); %,  
   
    if bSaveImage
        imwrite(frame2im(getframe(gcf)),[res_path num2str(frame) '.jpg']); 
    end

  
    rects = [positions(:,2) - target_sz(2)/2, positions(:,1) - target_sz(1)/2];
    rects(:,3) = target_sz(2);
    rects(:,4) = target_sz(1);

    fps = numel(img_files) / time;
    results.type = 'rect';
    results.res = rects;%each row is a rectangle
    results.fps = fps;

  end