function [precision, fps] = run_tracker(video, kernel_type, feature_type, show_visualization, show_plots)

	%path to the videos (you'll be able to choose one with the GUI).
    % 	base_path = './data/Benchmark/';
    base_path = 'G:\�о��������У�\�������\Ŀ�����\OTB100-videos';
    %G:\�о��������У�\�������\Ŀ�����\OTB100-videos��H:\��׳׳\���ݼ�\UAV123\data_seq\UAV123�� H:\��׳׳\���ݼ�\�Լ�����\֡����
	%default settings
	if nargin < 1, video = 'choose'; end %�����������ĸ���С��1������ô��video��Ĭ��ֵ��ִֻ����һ�����choose
	if nargin < 2, kernel_type = 'gaussian'; end %linear��gaussian
	if nargin < 3, feature_type = 'hogcolor'; end %hogcolor
	if nargin < 4, show_visualization =~ strcmp(video, 'all'); end %Ϊ����ʾ��Ӧͼ������ԭʼ�㷨��ȡ
	if nargin < 5, show_plots = ~strcmp(video, 'all'); end


	%parameters according to the paper. at this point we can override
	%parameters based on the chosen kernel or feature type
	kernel.type = kernel_type;
	
	features.gray = false;
	features.hog = false;
	features.hogcolor = false;
	padding = 1.5;  %Ŀ����Χ�Ķ�������ٷֱ�
%     padding = 2;  %extra area surrounding the target

	lambda = 1e-4;  %regularization ���ƹ���ϵ����򻯲�����ģ�ͷ����е����Իع�
	output_sigma_factor = 0.1;  %spatial bandwidth (proportional to target)�ռ��������Ŀ��ɱ�����
	
	switch feature_type
	case 'gray'
		interp_factor = 0.075;  %����Ӧ�����Բ�ֵ����

		kernel.sigma = 0.2;  %gaussian kernel bandwidth ��˹�ں˴���
		
		kernel.poly_a = 1;  %polynomial kernel additive term ����ʽ�˼ӷ���
		kernel.poly_b = 7;  %polynomial kernel exponent ����ʽ��ָ��
	
		features.gray = true;   %�Ҷ�
		cell_size = 1;
		
	case 'hog'
		interp_factor = 0.02;  %����Ӧ���Բ�ֵ����
		
		kernel.sigma = 0.5;   %gaussian kernel bandwidth ��˹�ں˴���
		
		kernel.poly_a = 1;
		kernel.poly_b = 9;
		
		features.hog = true; %ֱ��ͼ
		features.hog_orientations = 9;
		cell_size = 4;
    case 'hogcolor'
		interp_factor = 0.02;  %interp_factor�Ǹ�����������Ӧ���ʣ�������ģ�͵ļ�������
		
		kernel.sigma = 0.5; %��˹�ں˴���		
		
		kernel.poly_a = 1; %����ʽ�˼ӷ���
		kernel.poly_b = 9; %����ʽ�ں�ָ��
		
		features.hogcolor = true;
		features.hog_orientations = 9;
		cell_size = 4;
    case 'deep'
        interp_factor = 0.02;
		
		kernel.sigma = 0.5;
		
		kernel.poly_a = 1;
		kernel.poly_b = 9;
		
		features.deep = true;  %���
		cell_size = 8;
        init_vgg;   %VGG16��ȡͼ������
		
	otherwise
		error('Unknown feature.')
    end

    
    global params;
	%params.output_sigma_factor = 1/16;		% standard deviation for the desired translation filter output
    params.scale_sigma_factor = 1/4;        % standard deviation for the desired scale filter output
    params.lambda = 1e-2;					% regularization weight (denoted "lambda" in the paper)
    params.learning_rate = 0.025;%0.025			% tracking model learning rate (denoted "eta" in the paper)
    params.number_of_scales = 33;           % number of scale levels (denoted "S" in the paper)
    params.scale_step = 1.02;               % Scale increment factor (denoted "a" in the paper)
    params.scale_model_max_area = 512;      % the maximum size of scale examples

    

	assert(any(strcmp(kernel_type, {'linear', 'polynomial', 'gaussian'})), 'Unknown kernel.')
    %��matlab��assert���������ж�һ��expression�Ƿ����
    %strcmp���������ַ����Ƚϵĺ���

	switch video
	case 'choose'
		%ask the user for the video, then call self with that video name.
		video = choose_video(base_path);
		if ~isempty(video)
			[precision, fps] = run_tracker(video, kernel_type, ...
				feature_type, show_visualization, show_plots);
			
			if nargout == 0  %don't output precision as an argument
				clear precision
			end
		end
		
		
	case 'all'
		%all videos, call self with each video name.
		
		%only keep valid directory names
		dirs = dir(base_path);
		videos = {dirs.name};
		videos(strcmp('.', videos) | strcmp('..', videos) | ...
			strcmp('anno', videos) | ~[dirs.isdir]) = [];
		
		%the 'Jogging' sequence has 2 targets, create one entry for each.
		%we could make this more general if multiple targets per video
		%becomes a common occurence.
		videos(strcmpi('Jogging', videos)) = [];
		videos(end+1:end+2) = {'Jogging.1', 'Jogging.2'};
		
		all_precisions = zeros(numel(videos),1);  %to compute averages����Ԫ��ֵ����������һ��numel��1�ľ���
		all_fps = zeros(numel(videos),1);
		
		if ~exist('matlabpool', 'file')
			%no parallel toolbox, use a simple 'for' to iterate
			for k = 1:numel(videos)
				[all_precisions(k), all_fps(k)] = run_tracker(videos{k}, ...
					kernel_type, feature_type, show_visualization, show_plots);
			end
		else
			%evaluate trackers for all videos in parallel
			if parpool('size') == 0
				parpool open;
			end
			parfor k = 1:numel(videos)
				[all_precisions(k), all_fps(k)] = run_tracker(videos{k}, ...
					kernel_type, feature_type, show_visualization, show_plots);
			end
		end
		
		%compute average precision at 20px, and FPS
        %����20px��ƽ�����Ⱥ�FPS     px������
		mean_precision = mean(all_precisions);
		fps = mean(all_fps);
		fprintf('\nAverage precision (20px):% 1.3f, Average FPS:% 4.2f\n\n', mean_precision, fps)
		if nargout > 0
			precision = mean_precision;
		end
		
		
	case 'benchmark'
		%running in benchmark mode - this is meant to interface easily
		%with the benchmark's code.
		
		%get information (image file names, initial position, etc) from
		%the benchmark's workspace variables
		seq = evalin('base', 'subS');%���в�ͬ������������κκ���
		target_sz = seq.init_rect(1,[4,3]);%Ŀ���СΪ60x60
		pos = seq.init_rect(1,[2,1]) + floor(target_sz/2);
		img_files = seq.s_frames;
		video_path = [];
		
		%call tracker function with all the relevant parameters
		positions = tracker(video_path, img_files, pos, target_sz, ...
			padding, kernel, lambda, output_sigma_factor,interp_factor,...
			cell_size, features, false);%  
		
		%return results to benchmark, in a workspace variable
		rects = [positions(:,2) - target_sz(2)/2, positions(:,1) - target_sz(1)/2];
		rects(:,3) = target_sz(2);
		rects(:,4) = target_sz(1);
		res.type = 'rect';
		res.res = rects;
		assignin('base', 'res', res);
		
		
	otherwise
		%we were given the name of a single video to process.
	
		%get image file names, initial state, and ground truth for evaluation
		[img_files, pos, target_sz, ground_truth, video_path] = load_video_info(base_path, video);
		
		
		%call tracker function with all the relevant parameters
		[positions, time] = tracker(video_path, img_files, pos, target_sz, ...
			padding, kernel, lambda, output_sigma_factor,interp_factor,...
			cell_size, features, show_visualization);% 
		
%         clear results
%         results{1}.type = 'rect';
%         x = positions(:,2);
%         y = positions(:,1);
%         w = target_sz(2) * ones(size(x, 1), 1);
%         h = target_sz(1) * ones(size(x, 1), 1);
%         results{1}.res = [x-w/2, y-h/2, w, h];
%         
%         results{1}.startFame = 1;
%         results{1}.annoBegin = 1;
%         results{1}.len = size(x, 1);
%         
%         frames = {'David', 300, 465; %770
%             'Football1', 1, 74;
%             'Freeman3', 1, 460;
%             'Freeman4', 1, 283};
%         
%         idx = find(strcmpi(video, frames(:,1)));
%         
%         if ~isempty(idx)
%             results{1}.startFame = frames{idx, 2};
%             results{1}.len = frames{idx, 3} - frames{idx, 2}; +1;
%         end
%         res_path = ['KCF_results_' feature_type '/'];
%         if ~isdir(res_path)
%             mkdir(res_path);
%         end
%         save([res_path lower(video) '_kcf_' feature_type '8.mat'], 'results');
        
        
		%calculate and show precision plot, as well as frames-per-second
		precisions = precision_plot(positions, ground_truth, video, show_plots);
		fps = numel(img_files) / time;

		fprintf('%12s - Precision (20px):% 1.3f, FPS:% 4.2f\n', video, precisions(20), fps)

		if nargout > 0
			%return precisions at a 20 pixels threshold
			precision = precisions(20);
        end
        

	end
end
