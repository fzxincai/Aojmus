1.You can run the 'download_videos. m' in  "Aojmus" to get the OTB - 50, the OTB - 100, or directly to http://cvlab.hanyang.ac.kr/tracker_benchmark/datasets.html to download.
2.Change the video path under "run_tracker.m" in "Aojmus", which is the saved OTB dataset path. Then run, you can get the accuracy and frame rate of each video sequence.

If you want to get the comparison results of this algorithm and other algorithms, you need to do the following configuration:
a. Download "tracker_benchmark_v1.0" from http://cvlab.hanyang.ac.kr/tracker_benchmark/benchmark_v10.html and perform simple configuration, the tutorial can be searched online;
b. Change "configTrackers.m" in "tracker_benchmark_v1.0\util" to add the algorithm to be compared;
c. Change "configSeqs.m" in "tracker_benchmark_v1.0\util", select the video sequence to be tested, and pay attention to the save path of the video sequence;
d. Run "main_running.m" in "tracker_benchmark_v1.0" to get the ".mat" file output by each algorithm in b. Then run "perfPlot.m" and "drawResultBB.m" respectively to get the curve graph and tracking results of each video sequence.

We provide the source code of "Aojmus", the ".mat" file output by the Aojmus algorithm in the paper in "tracker_benchmark_v1.0", and the line graph data in Figure 4 in the paper. ".mat" is contained in the "Results_OPE_CVPR13" folder and can be used directly in "tracker_benchmark_v1.0\results"After configuring "tracker_benchmark_v1.0", you can directly run and display the results. This article only compares the "OPE" of the algorithm. The 66 video sequences selected are as follows:

'BlurCar1','Bird2','BlurCar3','BlurCar4','boy','Car2','Car24','Coupon','coke','Dancer','crossing','Dancer2','david2','david3','Dog','dog1','doll','fish','Human8','Jogging1','lemming','Man','MountainBike','Mhyang','subway','suv','basketball','BlurCar2','BlurFace','Crowds','david','DragonBaby','dudek','girl','RedTeam','singer2','skating1','soccer','sylvester','trellis','carScale','Gym','Twinnings','bolt','Human4','freeman4','walking','Car1','Surfer','football','football1','BlurBody','Board','car4','liquor','walking2','freeman4','Box','faceocc2','matrix','Bird1','Jogging2','carDark','faceocc1','singer1','woman'

