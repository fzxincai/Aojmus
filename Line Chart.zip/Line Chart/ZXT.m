clc;
clear all;
tx=xlsread('ZXT.xlsx');
 
frame=tx(:,1);
Fmax=tx(:,2);
threshold_Fmax=tx(:,3);
APCE=tx(:,4);
threshold_APCE=tx(:,5);
RSFM=tx(:,6);
threshold_rsfm=tx(:,7);
N=tx(:,8);
threshold_n=tx(:,9);
x=tx(:,10);
y=tx(:,11);
z=tx(:,12);


subplot(2,2,1)
plot(frame,Fmax,'r')
title('��1��')
xlabel('Frame');
hold on
plot(frame,threshold_Fmax,'b')
legend('Fmax','Average');
% hold on
% plot(frame,x,'b')
% legend('Fmax','Average1','Average2');

subplot(2,2,2)
plot(frame,APCE,'r')
title('��2��')
xlabel('Frame');
hold on
plot(frame,threshold_APCE,'b')
legend('APCE','Average');
% hold on
% plot(frame,y,'b')
% legend('APCE','Average1','Average2');

subplot(2,2,3)
plot(frame,RSFM,'r')
title('��3��')
xlabel('Frame');
hold on
plot(frame,threshold_rsfm,'b')
legend('RSFM','Average');
% hold on
% plot(frame,z,'b')
% legend('RSFM','Average1','Average2');

subplot(2,2,4)
plot(frame,N,'r')
title('��4��')
xlabel('Frame');
hold on
plot(frame,threshold_n,'b')
legend('N','Average');
