
% This script downloads and extracts all videos to the path specified
% below.
%
% Joao F. Henriques, 2014
% http://www.isr.uc.pt/~henriques/


%local path where the videos will be located.
%note that if you change it here, you must also change it in RUN_TRACKER.
base_path = 'F:\XXXXXXXX\OTB100-videos';


%list of videos to download
videos = {'Basketball','Biker','Bird1','BlurBody','BlurCar2','BlurFace','BlurOwl','Bolt','Box', ...
    'Car1','Car4','CarDark','CarScale','ClifBar','Couple','Crowds','David','Deer', ...
    'Diving','DragonBaby','Dudek','Football','Freeman4','Girl','Human3','Human4','Human6', ...
    'Human9','Ironman','Jump','Jumping','Liquor','Matrix','MotorRolling','Panda','RedTeam', ...
    'Shaking','Singer2','Skating1','Skating2','Skiing','Soccer','Surfer','Sylvester','Tiger2', ...
    'Trellis','Walking','Walking2','Woman','Bird2','BlurCar1','BlurCar3','BlurCar4','Board', ...
    'Bolt2','Boy','Car2','Car24','Coke','Coupon','Crossing','Dancer','Dancer2', ...
    'David2','David3','Dog','Dog1','Doll','FaceOcc1','FaceOcc2','Fish','FleetFace', ...
    'Football1','Freeman1','Freeman3','Girl2','Gym','Human2','Human5','Human7','Human8', ...
    'Jogging','KiteSurf','Lemming','Man','Mhyang','MountainBike','Rubik','Singer1','Skater',  ...
    'Skater2','Subway','Suv','Tiger1','Toy','Trans','Twinnings','Vase'};


if ~exist(base_path, 'dir'),  %create if it doesn't exist already
	mkdir(base_path);
end

if ~exist('parpool', 'file'),
	%no parallel toolbox, use a simple 'for' to iterate
	disp('Downloading videos one by one, this may take a while.')
	disp(' ')
	
	for k = 1:numel(videos),
		disp(['Downloading and extracting ' videos{k} '...']);
		unzip(['http://cvlab.hanyang.ac.kr/tracker_benchmark/seq/' videos{k} '.zip'], base_path);
	end
	
else
	%download all videos in parallel
	disp('Downloading videos in parallel, this may take a while.')
	disp(' ')
	
	if parpool('size') == 0,
		parpool open;
	end
	parfor k = 1:numel(videos),
		disp(['Downloading and extracting ' videos{k} '...']);
		unzip(['http://cvlab.hanyang.ac.kr/tracker_benchmark/seq/' videos{k} '.zip'], base_path);
	end
end

